#mpg - Miles per Gallon
#disp - displacement, in cubic inches
#hp - horsepower
#drat - driveshaft ratio 
#wt - weight
#qsec - 1/4 mile time; a measure of acceleration
#carb - # of carburetors.
#importing require libraries
library(ClusterR) 
library(cluster)
library(caTools)
library(dplyr)
library(ggplot2)
library(stats)
library(ggfortify)
library(corrplot)
library(ggplot2)
library(GGally)
library(factoextra)
library(data.table)
# Importing the data on which analysis needs to be done
data("mtcars")
mtcars
df=mtcars
df
dim(df)
#DATA CLEANING
#Removing unwanted data / column
df=df[,-2]
df=df[,1:6]
df
nrow(df)
ncol(df)
colnames(df)
#checking for null values in the dataset
is.na(df)
sum(is.na(df))
summary(df)
#finding pearson correlation
b=cor(df,method = "pearson")
corrplot(abs(b),method="color",cl.lim=c(0,1))
#function to plot wssplot for finding elbow curve
wssplot <- function(data,nc=15,seed=1234) {
  wss<-(nrow(data)-1)*sum(apply(data,2,var)) 
  for(i in 2:nc){
      set.seed(seed)
      wss[i] <- sum(kmeans(data, centers=i)$withinss)} 
      plot(1:nc,wss,type="b",xlab = "no. of Clusters",ylab="within grp squares")
}

wssplot(df)


#comparing qsec with wt in kmeans
set.seed(1)
km01=kmeans(df,2)
df["cluster"]= as.factor(km01$cluster) 
ggpairs(df, aes(colour = cluster, alpha = 0.4))
new_Data1= data.frame(df$qsec,df$wt) 
new_Data1 <- setNames(new_Data1,c('qsec','wt')) 
set.seed(1)
km1=kmeans(new_Data1,2)
autoplot(km1,new_Data1,frame=TRUE)
km1$centers
#comparing qsec with drat in kmeans
set.seed(1)
km02=kmeans(df,2)
df["cluster"]= as.factor(km02$cluster) 
ggpairs(df, aes(colour = cluster, alpha = 0.4))
new_Data2= data.frame(df$qsec,df$drat) 

new_Data2 <- setNames(new_Data2,c('qsec','drat')) 
set.seed(1)
km2=kmeans(new_Data2,2)

autoplot(km2,new_Data2,frame=TRUE)
km2$centers

# Using the dendrogram to find the optimal number of clusters
dendrogram = hclust(d = dist(head(new_Data1, method = 'euclidean'), method = 'ward.D') 
plot(dendrogram,
  main = paste('Dendrogram'), 
  xlab = 'drat', 
  ylab = 'wt')
# Using the dendrogram to find the optimal number of clusters
dendrogram = hclust(d = dist(new_Data2, method = 'euclidean'), method = 'ward.D') 
plot(dendrogram,
  main = paste('Dendrogram'), 
  xlab = 'drat', 
  ylab = 'qsec')

set.seed(1)
# Fitting Hierarchical Clustering to the dataset qsec and wt
hc = hclust(d = dist(new_Data1, method = 'euclidean'), method = 'ward.D') 
y_hc = cutree(hc, 2)
# Visualize the result in a scatter plot qsec and wt
fviz_cluster(list(data = new_Data1, cluster = y_hc))

set.seed(1)
# Fitting Hierarchical Clustering to the dataset qsec and drat
hc = hclust(d = dist(new_Data2, method = 'euclidean'), method = 'ward.D') 
y_hc = cutree(hc, 2)
# Visualize the result in a scatter plot qsec and drat
fviz_cluster(list(data = new_Data2, cluster = y_hc))


